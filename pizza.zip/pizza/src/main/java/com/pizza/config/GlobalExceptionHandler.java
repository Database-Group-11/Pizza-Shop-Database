package com.pizza.config;

public class GlobalExceptionHandler {
}
