package com.pizza.config;

public class CorsConfig {
}
