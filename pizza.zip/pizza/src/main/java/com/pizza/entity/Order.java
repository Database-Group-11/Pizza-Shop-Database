package com.pizza.entity;

public class Order {
}
