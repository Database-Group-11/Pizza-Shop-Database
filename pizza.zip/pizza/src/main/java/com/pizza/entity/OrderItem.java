package com.pizza.entity;

public class OrderItem {
}
