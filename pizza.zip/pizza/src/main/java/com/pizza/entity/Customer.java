package com.pizza.entity;

public class Customer {
}
