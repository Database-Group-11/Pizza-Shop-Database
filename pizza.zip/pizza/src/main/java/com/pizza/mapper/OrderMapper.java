package com.pizza.mapper;

public class OrderMapper {
}
