package com.pizza.mapper;

public class CustomerMapper {
}
