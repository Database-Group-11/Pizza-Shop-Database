package com.pizza.dto;

public class OrderCreateDTO {
}
