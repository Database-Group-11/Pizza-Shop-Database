package com.pizza.dto;

public class OrderDTO {
}
