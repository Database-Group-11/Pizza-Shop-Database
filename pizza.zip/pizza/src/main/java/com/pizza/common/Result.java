package com.pizza.common;

public class Result {
}
