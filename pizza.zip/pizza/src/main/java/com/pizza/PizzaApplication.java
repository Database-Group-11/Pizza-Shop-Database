package com.pizza;

public class PizzaApplication {
}
